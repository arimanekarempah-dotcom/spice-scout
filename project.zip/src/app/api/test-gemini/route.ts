export async function GET() {
  return Response.json({ ok: true, test: "route works" });
}
